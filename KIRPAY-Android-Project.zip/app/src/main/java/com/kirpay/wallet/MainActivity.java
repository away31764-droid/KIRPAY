package com.kirpay.wallet;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(16,24,39);
    private final int PANEL = Color.rgb(27,41,57);
    private final int TILE = Color.rgb(38,56,73);
    private final int MINT = Color.rgb(24,199,165);
    private final int WHITE = Color.WHITE;
    private long balance = 250000;
    private LinearLayout root, content;
    private String page = "home";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        showApp();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private void pad(View v, int p) { v.setPadding(p,p,p,p); }
    private String rupiah(long n) {
        return "Rp " + NumberFormat.getInstance(new Locale("id","ID")).format(n);
    }
    private TextView button(String label, Runnable action) {
        TextView b = text(label, 15, WHITE, true);
        b.setGravity(Gravity.CENTER); b.setPadding(14,15,14,15);
        b.setBackground(shape(TILE, 22));
        b.setOnClickListener(v -> action.run());
        return b;
    }
    private void showApp() {
        root = column(); root.setBackgroundColor(BG); root.setPadding(20,18,20,18);
        setContentView(root);
        LinearLayout header = row();
        TextView mark = text("K",22,BG,true); mark.setGravity(Gravity.CENTER);
        mark.setBackground(shape(MINT,16)); mark.setWidth(46); mark.setHeight(46);
        header.addView(mark);
        LinearLayout brand = column(); brand.setPadding(12,0,0,0);
        brand.addView(text("KIRPAY",22,WHITE,true));
        brand.addView(text("DIGITAL WALLET",10,0xffa8b5c7,true));
        header.addView(brand);
        root.addView(header);
        TextView demo = text("DEMO VERSION • SALDO SIMULASI",11,MINT,true);
        demo.setPadding(0,18,0,12); root.addView(demo);

        content = column();
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,0,1);
        root.addView(content,cp);
        renderPage();

        LinearLayout nav = row(); nav.setGravity(Gravity.CENTER);
        String[][] items = {{"⌂","Beranda","home"},{"▤","Riwayat","history"},{"●","Profil","profile"}};
        for (String[] item : items) {
            TextView n = text(item[0]+"\n"+item[1],13,
                    page.equals(item[2]) ? MINT : 0xffa8b5c7,true);
            n.setGravity(Gravity.CENTER); n.setPadding(18,14,18,8);
            n.setOnClickListener(v -> { page=item[2]; showApp(); });
            nav.addView(n,new LinearLayout.LayoutParams(0,-2,1));
        }
        root.addView(nav);
    }
    private void renderPage() {
        content.removeAllViews();
        if (page.equals("home")) {
            LinearLayout card = column(); card.setBackground(shape(0xff183b48,28)); pad(card,20);
            card.addView(text("TOTAL SALDO",13,0xffc6e8e3,false));
            TextView amount = text(rupiah(balance),29,WHITE,true);
            amount.setPadding(0,12,0,8); card.addView(amount);
            card.addView(text("Saldo simulasi KIRPAY",12,0xffb7d8d4,false));
            content.addView(card);
            TextView heading = text("Layanan KIRPAY",18,WHITE,true);
            heading.setPadding(0,24,0,12); content.addView(heading);
            LinearLayout r1 = row(); r1.setPadding(0,0,0,10);
            r1.addView(button("＋  Top Up",()->{page="topup";showApp();}),new LinearLayout.LayoutParams(0,-2,1));
            Space gap = new Space(this); r1.addView(gap,new LinearLayout.LayoutParams(10,1));
            r1.addView(button("➤  Transfer",()->{page="transfer";showApp();}),new LinearLayout.LayoutParams(0,-2,1));
            content.addView(r1);
            LinearLayout r2 = row();
            r2.addView(button("▦  QRIS Demo",()->toast("QRIS hanya tampilan demo.")),new LinearLayout.LayoutParams(0,-2,1));
            Space gap2 = new Space(this); r2.addView(gap2,new LinearLayout.LayoutParams(10,1));
            r2.addView(button("▤  Riwayat",()->{page="history";showApp();}),new LinearLayout.LayoutParams(0,-2,1));
            content.addView(r2);
            TextView info = text("Selamat datang di KIRPAY. Semua transaksi pada versi ini hanya simulasi dan tidak memindahkan uang sungguhan.",13,0xffa8b5c7,false);
            info.setPadding(2,24,2,0); content.addView(info);
        } else if (page.equals("topup")) {
            content.addView(text("Top Up Demo",23,WHITE,true));
            content.addView(text("Pilih nominal untuk menambah saldo simulasi.",13,0xffa8b5c7,false));
            int[] values={10000,25000,50000,100000};
            for(int v:values) {
                TextView b=button(rupiah(v)+"     +",()->{balance+=v;toast("Top up demo berhasil.");page="home";showApp();});
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=12;content.addView(b,lp);
            }
        } else if (page.equals("transfer")) {
            content.addView(text("Transfer Demo",23,WHITE,true));
            content.addView(text("Simulasi transfer antar pengguna. Tidak mengirim uang sungguhan.",13,0xffa8b5c7,false));
            EditText recipient=new EditText(this);recipient.setHint("ID penerima (contoh: KIR-0002)");recipient.setTextColor(WHITE);recipient.setHintTextColor(0xffa8b5c7);
            content.addView(recipient);
            EditText nominal=new EditText(this);nominal.setHint("Nominal transfer");nominal.setInputType(2);nominal.setTextColor(WHITE);nominal.setHintTextColor(0xffa8b5c7);
            content.addView(nominal);
            TextView send=button("Lanjutkan Demo",()->{
                String val=nominal.getText().toString();
                if(recipient.getText().toString().trim().isEmpty() || val.isEmpty()){toast("Isi ID penerima dan nominal.");return;}
                long amount; try{amount=Long.parseLong(val);}catch(Exception e){toast("Nominal tidak valid.");return;}
                if(amount<=0 || amount>balance){toast("Saldo demo tidak mencukupi.");return;}
                balance-=amount;toast("Transfer simulasi berhasil.");page="home";showApp();
            });
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=18;content.addView(send,lp);
        } else if (page.equals("history")) {
            content.addView(text("Riwayat Transaksi",23,WHITE,true));
            TextView h=text("Saldo awal demo                         +Rp 250.000",14,MINT,true);h.setPadding(0,22,0,12);content.addView(h);
            content.addView(text("Riwayat ini hanya contoh. Versi ini belum memakai database.",13,0xffa8b5c7,false));
        } else {
            content.addView(text("Profil Pengguna",23,WHITE,true));
            TextView p=text("Demo User\nID: KIR-000001\nVersi aplikasi: 1.0",16,WHITE,true);p.setPadding(0,25,0,0);content.addView(p);
            content.addView(text("Akun demo lokal — belum ada autentikasi atau penyimpanan akun.",13,0xffa8b5c7,false));
        }
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
