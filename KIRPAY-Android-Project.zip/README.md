# KIRPAY E-WALLET — Android prototype

This is a native Android Studio starter project for a DEMO wallet only.

## Included
- KIRPAY dark/turquoise interface
- Demo balance
- Simulated top-up
- Simulated transfer with local balance deduction
- Demo QRIS menu
- Basic history and profile screens

## Build an APK
1. Install Android Studio on a computer.
2. Open this `KIRPAY-Android` folder in Android Studio.
3. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.

## Important limitations
This prototype does not connect to a bank, payment gateway, QRIS network, or server.
It has no real login, identity verification, secure transaction ledger, or real-money capability.
Do not use it to collect deposits or process payments. A real e-wallet requires a compliant,
licensed payment partner, security review, backend infrastructure, and applicable regulatory approvals.
